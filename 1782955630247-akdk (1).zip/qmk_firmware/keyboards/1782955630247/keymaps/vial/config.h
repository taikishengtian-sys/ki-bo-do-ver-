#pragma once

#define VIAL_KEYBOARD_UID {0xee, 0x17, 0xbb, 0xbb, 0xdf, 0x3e, 0x81, 0xb3}
#define VIAL_TAP_DANCE_ENTRIES 8
#define VIAL_COMBO_ENTRIES 8
#define PICO_FLASH_SIZE_BYTES (1 * 1024 * 1024)